#include "boundary.h"

void treatBoundary(double *collideField, int* flagField, const double * const wallVelocity, int xlength){
  /* TODO */
}

