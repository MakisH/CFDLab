#include "collision.h"

void computePostCollisionDistributions(double *currentCell, const double * const tau, const double *const feq){
  /* TODO */
}

void doCollision(double *collideField, int *flagField,const double * const tau,int xlength){
  /* TODO */
}

