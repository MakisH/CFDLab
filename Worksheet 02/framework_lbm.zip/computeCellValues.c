#include "computeCellValues.h"

void computeDensity(const double *const currentCell, double *density){
  /* TODO */
}

void computeVelocity(const double * const currentCell, const double * const density, double *velocity){
  /* TODO */
}

void computeFeq(const double * const density, const double * const velocity, double *feq){
 /* TODO */
}

