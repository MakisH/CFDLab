#include "streaming.h"

void doStreaming(double *collideField, double *streamField,int *flagField,int xlength){
  /* TODO */
}

