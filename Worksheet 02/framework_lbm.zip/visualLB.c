#include "visualLB.h"

void writeVtkOutput(const double * const collideField, const int * const flagField, const char * filename, unsigned int t, int xlength) {
  /* TODO */
}

